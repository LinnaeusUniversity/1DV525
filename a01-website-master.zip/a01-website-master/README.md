# A01 Website

Template for Assignment 01 (A01).

## Links

## Web programming introduction coursepress page

[Web programming course press](https://coursepress.lnu.se/kurs/introduction-to-web-programming/)

## Web programming introduction 20VT-1DV525 assignment 01

[Web programming course press](https://gitlab.lnu.se/1dv525/student/rq222ah/a01-website)

# HTML & CSS

**Showing that I can write in Markdown**

1. These requirements are mainly related to HTML anc CSS constructs.

1. Stylesheet `css/style.css`
1. Prepare the file `css/style.css` to contain style for the website.

1. Add a comment at the top of the file and add your name and write "A01".
1. Markdown example "And if you'd like to use syntax highlighting, include the language:"

```javascript
if (isAwesome) {
  return true;
}
```

###### End of ReadMe
