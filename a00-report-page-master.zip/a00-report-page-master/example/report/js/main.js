/**
 * A function to wrap it all in.
 */
(function () {
  'use strict'

  console.log('All ready.')
}())
